Tobias Lee
tobiasle@usc.edu
8011734618

This project is pretty simple to run. Just run the project. To change the search, change the queueing function on line 246 of HW2.java. Options are GFQ and ASQ passing h1 or h2 as the argument

To compile: in the directory with HW2.java:
	javac HW2.java
To run:
	java HW2

Question 1: Both h1 and h2 return the same results to me in terms of nodes searched. I ran my program and used pencil&paper and got the same results both ways of examining every node.

Question 2: I would expect h2 to be better because the heuristic is larger on every count, but to my surprise, it didn't change anything!